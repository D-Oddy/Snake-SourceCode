#ifndef MENUS_H
#define MENUS_H

#include "Game.h"

class Menus 
{
private:

public:
	Menus();

	void mainMenu()
		

};



#endif // !MENUS_h

